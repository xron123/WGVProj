package com.AutomationWGV.TestCases;

import java.awt.AWTException;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.AutomationWGV.BaseClass.BaseWGV;
import com.AutomationWGV.Pages.PersonlicheDatenEingeben;
import com.AutomationWGV.Pages.FahrzeugklassenPage;
import com.AutomationWGV.Pages.PramieBeantragenPage;

public class FahrzeugklassenTest extends BaseWGV {
	FahrzeugklassenPage fahrzeugklassen = new FahrzeugklassenPage();
	PersonlicheDatenEingeben personlicheDatenEingeben = new PersonlicheDatenEingeben();
	PramieBeantragenPage pramieBeantragenPage = new PramieBeantragenPage();

	public FahrzeugklassenTest() throws IOException {
		super();

	}

	@Test(priority = 1)
	public void TC001_Verify_Premium_Request_for_EPKW_Filling_All_The_Fields()
			throws AWTException, IOException, InterruptedException {

		boolean status = personlicheDatenEingeben.verify_Premium_Request_for_EPKW_Filling_All_The_Fields();
		Assert.assertTrue(status);
	}

	@Test(priority = 2)
	public void TC002_Verify_Error_Messages_When_No_Details_Entered()
			throws IOException, AWTException, InterruptedException {

		
		boolean status  = personlicheDatenEingeben.verify_Error_Messages_When_No_Details_Entered();
		
		Assert.assertTrue(status);

	}

	@Test(priority = 3)
	public void TC003_verify_Bonus_Request_Without_Accepting_Terms_And_Conditions()
			throws IOException, AWTException, InterruptedException {

		boolean status = personlicheDatenEingeben.verify_Bonus_Request_Without_Accepting_Terms_And_Conditions();

		Assert.assertTrue(status);
	}

	@Test(priority = 4)
	public void TC004_verify_Terms_And_Conditions_Not_Selected_By_Default()
			throws IOException, AWTException, InterruptedException {

		boolean status = personlicheDatenEingeben.verify_Terms_And_Conditions_Not_Selected_By_Default();
		Assert.assertFalse(status);
	}
}
