package com.AutomationWGV.BaseClass;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseWGV {
	
		public static WebDriver driver;
		public static Properties prop;
		public static Properties dataProp;
		
		
		public  BaseWGV () throws IOException {
			FileInputStream fissource = new FileInputStream(
					"C:\\Users\\Thahir\\eclipse-workspaceNew\\com.AutomationWGV\\src\\main\\java\\com\\AutomationWGV\\config\\config.properties");
			prop = new Properties();
			prop.load(fissource);
			
			FileInputStream fissource2 = new FileInputStream("C:\\Users\\Thahir\\eclipse-workspaceNew\\com.AutomationWGV\\src\\main\\java\\com\\Automation_TestData\\testData.properties");
				
			dataProp = new Properties();
			dataProp.load(fissource2);
		}

		@BeforeMethod
		public static void launchBrowser() throws IOException {

			String browserName = prop.getProperty("browser");

			{
				if (browserName.equalsIgnoreCase("chrome")) {

					//ChromeOptions Options = new ChromeOptions();
					//Options.addArguments("--remote-allow-origins=*");
					driver = new ChromeDriver();

				} else if (browserName.equalsIgnoreCase("edge")) {

					driver = new EdgeDriver();
				} else if (browserName.equalsIgnoreCase("firefox")) {
					driver = new FirefoxDriver();
				}
	            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
				driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(5));
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
				driver.get(prop.getProperty("url"));
	}

		}
		@AfterMethod
		public void tearDown() {
			driver.close();
		}

	}


