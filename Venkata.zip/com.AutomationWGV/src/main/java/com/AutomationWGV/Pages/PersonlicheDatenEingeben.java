package com.AutomationWGV.Pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.AutomationWGV.BaseClass.BaseWGV;

public class PersonlicheDatenEingeben extends BaseWGV  {

	FahrzeugklassenPage fahrzeugklassen = new FahrzeugklassenPage();
	PramieBeantragenPage pramieBeantragenPage = new PramieBeantragenPage();

	// Locators
	By CustomerTypePrivatePerson = By.xpath("//input[@value='PrivatePerson']");
	By DropDown = By.xpath("//mat-select[@role='combobox']");
	By ChooseFrau = By.xpath("//span[normalize-space()='Frau']");
	By VornameLoc = By.xpath("//input[@placeholder='Max']");
	By NachnameLoc = By.xpath("//input[@placeholder='Mustermann']");
	By EmailLoc = By.xpath("//input[@placeholder='max.mustermann@muster.de']");
	By KontoinhaberLoc = By.xpath("//input[@placeholder='Max Mustermann']");
	By IBANLoc = By.xpath("//input[@placeholder='z.B. DE45 7890 8965 5643 3454 00']");
	By WeiterPersonliche = By.xpath("//div[@class='ng-star-inserted']//span[@class='mat-mdc-button-touch-target']");
	By ErrorMsgAnrede = By.xpath(
			"\"//*[@id=\\\"cdk-step-content-0-1\\\"]/div/app-step2/form/div[1]/onpier-input/div/div/div/mat-form-field/div[2]\"");
	By ErrorMsgVorname = By.xpath("//p[normalize-space()='Bitte geben Sie Ihren Vornamen ein.']");
	By ErrorMsgNachrname = By.xpath("//p[normalize-space()='Bitte geben Sie Ihren Nachnamen ein.']");
	By ErrorMsgEmail = By.xpath("//p[normalize-space()='Bitte geben Sie Ihre E-Mail-Adresse ein.']");
	By ErrorMsgKontoinhaber = By.xpath("//p[contains(text(),'Bitte geben Sie Vor- und Nachname des Kontoinhaber')]");
	By ErrorMsgIBAN = By.xpath("//p[contains(text(),'Bitte geben Sie eine vollständige IBAN ein (z. B. ')]");

	public PersonlicheDatenEingeben() throws IOException {
		super();

	}

	public void selectCustomerType_Privatperson() {
		driver.findElement(CustomerTypePrivatePerson).click();

	}

	public void selectAnrede_Herr() throws InterruptedException {

		driver.findElement(DropDown).click();
		driver.findElement((ChooseFrau)).click();
	}

	public String retrieveErrorMsg_selectAnrede() {

		return driver.findElement(ErrorMsgAnrede).getText();

	}

	public void enter_Vorname(String Vorname) {

		driver.findElement((VornameLoc)).sendKeys(Vorname);
	}

	public String retrieveErrorMsg_Vorname() {

		return driver.findElement(ErrorMsgVorname).getText();
	}

	public void enter_Nachname(String Nachname) {

		driver.findElement(NachnameLoc).sendKeys(Nachname);
	}

	public String retrieveErrorMsg_Nachname() {

		return driver.findElement(ErrorMsgNachrname).getText();
	}

	public void enter_Email(String Email) {

		driver.findElement((EmailLoc)).sendKeys(Email);
	}

	public String retrieveErrorMsg_Email() {

		return driver.findElement(ErrorMsgEmail).getText();
	}

	public void enter_Kontoinhaber(String Kontoinhaber) {

		driver.findElement((KontoinhaberLoc)).sendKeys(Kontoinhaber);
	}

	public String retrieveErrorMsg_Kontoinhaber() {

		return driver.findElement(ErrorMsgKontoinhaber).getText();
	}

	public void enter_Enter_IBAN(String IBAN) {

		driver.findElement((IBANLoc)).sendKeys(IBAN);
	}

	public String retrieveErrorMsg_IBAN() {

		return driver.findElement(ErrorMsgIBAN).getText();
	}

	public void clickWeiter_Personliche() {
		WebElement element = driver.findElement((WeiterPersonliche));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", element);

	}

	public boolean verify_Premium_Request_for_EPKW_Filling_All_The_Fields()
			throws AWTException, IOException, InterruptedException {

		FahrzeugklassenPage.clickOnTheFahrzeugklassen();
		fahrzeugklassen.clickOnEcar();
		fahrzeugklassen.clickOnPrämieBeantragen_Sofort();
		fahrzeugklassen.upload_Fahrzeugschein_Vorderseite();
		fahrzeugklassen.upload_Fahrzeugschein_Ruckseite();
		Thread.sleep(2000);
		fahrzeugklassen.clickOn_Weiter();

		selectCustomerType_Privatperson();

		selectAnrede_Herr();

		enter_Vorname(dataProp.getProperty("Vorname")); // sourcing from tesData.properties
		enter_Nachname(dataProp.getProperty("Nachname"));
		enter_Email(dataProp.getProperty("Email"));
		enter_Kontoinhaber(dataProp.getProperty("Kontoinhaber"));
		enter_Enter_IBAN(dataProp.getProperty("IBAN"));
		clickWeiter_Personliche();
		pramieBeantragenPage.Click_TermsAndConditions_Eligibility();
		pramieBeantragenPage.Click_TermsAndConditions_Declaration();
		pramieBeantragenPage.clickOn_jetz_PrämieBeantragen();
		Thread.sleep(3000);
		boolean status = pramieBeantragenPage.retrieveSuccessConfirmation();
		return status;
	}

	public boolean verify_Error_Messages_When_No_Details_Entered()
			throws IOException, AWTException, InterruptedException {
		// FahrzeugklassenPage.clickOnTheFahrzeugklassen();
		fahrzeugklassen.clickOnEcar();
		fahrzeugklassen.clickOnPrämieBeantragen_Sofort();
		fahrzeugklassen.upload_Fahrzeugschein_Vorderseite();
		fahrzeugklassen.upload_Fahrzeugschein_Ruckseite();
		Thread.sleep(2000);
		fahrzeugklassen.clickOn_Weiter();
		selectCustomerType_Privatperson();
		driver.findElement(By.xpath("//*[@id=\"mat-select-0\"]/div")).click();
		// Thread.sleep(2000);
		enter_Vorname("");
		enter_Nachname("");
		enter_Email("");
		enter_Kontoinhaber("");
		enter_Enter_IBAN("");
		enter_Kontoinhaber("");
		String vorNameactualResult = retrieveErrorMsg_Vorname();
		boolean vorName_Expected_lResult = vorNameactualResult.equals(dataProp.getProperty("vorNameactualResul"));
		String nachNameActualResult = retrieveErrorMsg_Nachname();
		boolean nachNameExpectedResult = nachNameActualResult.equals(dataProp.getProperty("nachNameActualResult"));
		String emailExpectedResult = retrieveErrorMsg_Email();
		boolean emailActualResult = emailExpectedResult.equals(dataProp.getProperty("emailExpectedResult"));
		String KontoinhaberExpectedResult = retrieveErrorMsg_Kontoinhaber();
		boolean KontoinhaberActualResult = KontoinhaberExpectedResult
				.equals(dataProp.getProperty("KontoinhaberExpectedResult"));
		String IBAN_ExpectedResult = retrieveErrorMsg_IBAN();
		boolean IBAN_ActualResult = IBAN_ExpectedResult.equals(dataProp.getProperty("IBAN_ExpectedResult"));
		return vorName_Expected_lResult && nachNameExpectedResult && emailActualResult && KontoinhaberActualResult
				&& IBAN_ActualResult;

	}

	public boolean verify_Bonus_Request_Without_Accepting_Terms_And_Conditions()
			throws IOException, AWTException, InterruptedException {

		FahrzeugklassenPage.clickOnTheFahrzeugklassen();
		fahrzeugklassen.clickOnEcar();
		fahrzeugklassen.clickOnPrämieBeantragen_Sofort();
		fahrzeugklassen.upload_Fahrzeugschein_Vorderseite();
		fahrzeugklassen.upload_Fahrzeugschein_Ruckseite();
		Thread.sleep(2000);
		fahrzeugklassen.clickOn_Weiter();

		selectCustomerType_Privatperson();

		selectAnrede_Herr();

		enter_Vorname(dataProp.getProperty("Vorname")); // sourcing from tesData.properties
		enter_Nachname(dataProp.getProperty("Nachname"));
		enter_Email(dataProp.getProperty("Email"));
		enter_Kontoinhaber(dataProp.getProperty("Kontoinhaber"));
		enter_Enter_IBAN(dataProp.getProperty("IBAN"));
		clickWeiter_Personliche();
		boolean buttonStatus = pramieBeantragenPage.retrieve_jetz_PrämieBeantragenButton_Status();
		return buttonStatus;
	}

	public boolean verify_Terms_And_Conditions_Not_Selected_By_Default()
			throws IOException, AWTException, InterruptedException {

		FahrzeugklassenPage.clickOnTheFahrzeugklassen();
		fahrzeugklassen.clickOnEcar();
		fahrzeugklassen.clickOnPrämieBeantragen_Sofort();
		fahrzeugklassen.upload_Fahrzeugschein_Vorderseite();
		fahrzeugklassen.upload_Fahrzeugschein_Ruckseite();
		Thread.sleep(2000);
		fahrzeugklassen.clickOn_Weiter();

		selectCustomerType_Privatperson();

		selectAnrede_Herr();

		enter_Vorname(dataProp.getProperty("Vorname")); // sourcing from tesData.properties
		enter_Nachname(dataProp.getProperty("Nachname"));
		enter_Email(dataProp.getProperty("Email"));
		enter_Kontoinhaber(dataProp.getProperty("Kontoinhaber"));
		enter_Enter_IBAN(dataProp.getProperty("IBAN"));
		clickWeiter_Personliche();
		boolean Declaration_buttonStatus = pramieBeantragenPage.retrieve_TermsAndConditions_Declaration_Button_Status();
		boolean Eligibilty_buttonStatus = pramieBeantragenPage.retrieve_TermsAndConditions_Eligibility_Button_Status();
		return Declaration_buttonStatus&&Eligibilty_buttonStatus;

		
	}

}
