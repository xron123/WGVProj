package com.AutomationWGV.Pages;

import java.io.IOException;

import org.openqa.selenium.By;

import com.AutomationWGV.BaseClass.BaseWGV;

public class PramieBeantragenPage extends BaseWGV  {
	//PersonlicheDatenEingeben personlicheDatenEingeben =new PersonlicheDatenEingeben();
	FahrzeugklassenPage fahrzeugklassen = new FahrzeugklassenPage();
	By TermsElgibility = By.cssSelector("#mat-mdc-checkbox-1-input");
	By TermsDeclaration = By.cssSelector("#mat-mdc-checkbox-2-input");
	By PrämieBeantragen = By.xpath("//div[normalize-space()='Jetzt Prämie beantragen']");
	By SuccessMsg = By.xpath("//p[normalize-space()='Ihre THG-Prämie wird beantragt.']");
	

	public PramieBeantragenPage() throws IOException {
		super();
		
	}
	public void Click_TermsAndConditions_Eligibility() {
		
		driver.findElement(TermsElgibility).click();
	}
		
		public boolean retrieve_TermsAndConditions_Eligibility_Button_Status() {
			
			return driver.findElement(TermsElgibility).isSelected();	
}
		
		
public void Click_TermsAndConditions_Declaration() {
		
		driver.findElement(TermsDeclaration).click();
}

public boolean retrieve_TermsAndConditions_Declaration_Button_Status() {
	
	return driver.findElement(TermsDeclaration).isSelected();
	
}
public void clickOn_jetz_PrämieBeantragen() {
	
	driver.findElement(PrämieBeantragen).click();
}

public boolean retrieve_jetz_PrämieBeantragenButton_Status () {
	
	return driver.findElement(PrämieBeantragen).isEnabled();
}

public boolean retrieveSuccessConfirmation () {
	String actualMessage= driver.findElement((SuccessMsg)).getText();
	return  actualMessage.equals("Ihre THG-Prämie wird beantragt.");
}

}


