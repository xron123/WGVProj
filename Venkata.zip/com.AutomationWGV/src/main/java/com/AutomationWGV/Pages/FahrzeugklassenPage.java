package com.AutomationWGV.Pages;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;

import com.AutomationWGV.BaseClass.BaseWGV;
import com.AutomationWGV_Utils.FileUploader;

public class FahrzeugklassenPage extends BaseWGV {
	static By Fahrzeugklassen = By.cssSelector("body app-root div div div a:nth-child(2)");
	By EPKW = By.xpath("//span[normalize-space()='E-PKW']");
	By PrämieBeantragenSofort = By
			.xpath("//*[@id=\"BonusModel\"]/div/mat-card[2]/mat-card-content/div[2]/div/button/span[2]");
	By WeiterButton = By.xpath(
			"//app-step1[@class='ng-star-inserted']//div[@class='flex justify-center items-center'][normalize-space()='Weiter']");
	By clickOnApplyForBonusLocator = By.xpath("//p[normalize-space()='Flex-Prämie']");
	By clickOnVehicleClassesLocator = By.cssSelector("body app-root div div div a:nth-child(2)");

	FileUploader fileUploader = new FileUploader();

	public FahrzeugklassenPage() throws IOException {
		super();

	}

	public static void clickOnTheFahrzeugklassen() {

		driver.findElement(Fahrzeugklassen).click();

	}

	public void clickOnVehicleClasses() {

		driver.findElement(clickOnVehicleClassesLocator).click();

	}

	public void clickOnEcar() {

		driver.findElement((EPKW)).click();
	}

	public void clickOnPrämieBeantragen_Sofort() {

		driver.findElement(PrämieBeantragenSofort).click();

	}

	public void clickOnApplyForBonus() {

		driver.findElement((clickOnApplyForBonusLocator)).click();

	}

	public void upload_Fahrzeugschein_Vorderseite() throws IOException, AWTException {

		fileUploader.uploadFile(".inline", "\\src\\main\\java\\Fahrzeugschein_Files\\front.png");

	}

	public void upload_Fahrzeugschein_Ruckseite() throws AWTException {

		fileUploader.uploadFile("label[for='Fahrzeugschein Rückseite'] span[class='distributor-color']",
				"\\src\\main\\java\\Fahrzeugschein_Files\\back.png");
	}

	public void clickOn_Weiter() {

		driver.findElement(WeiterButton).click();
	}
}
