package com.AutomationWGV_Utils;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.AutomationWGV.BaseClass.BaseWGV;

public class FileUploader extends BaseWGV {

	public FileUploader() throws IOException {
		super();
		
	}
	public void uploadFile(String elementLocator, String filePath) throws AWTException {
	    driver.findElement(By.cssSelector(elementLocator)).click(); 
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    Robot robot = new Robot();
	    robot.delay(2000);
	    String projectpath = System.getProperty("user.dir"); 
	    StringSelection ss = new StringSelection(projectpath+filePath); 
	    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null); 

	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    robot.keyRelease(KeyEvent.VK_V);

	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	}

		}

		

